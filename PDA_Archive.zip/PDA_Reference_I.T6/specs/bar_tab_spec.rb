require('minitest/autorun')
require('minitest/rg')
require_relative('../'bar_tab)

class BarTabTest < MiniTest::Test

  def setup()

  end
end
